package Clases;
public class TrabajadorAlbañil extends Trabajador {
    private String descripcion_albañil= "El trabajador tiene un rol de albañil y sus quejas con respecto a la empresa son: ";

    public TrabajadorAlbañil(String nombre,String cedula,TGenero genero, String reporte, String direccion, String telefono) {
        super(nombre, cedula, genero,reporte, direccion, telefono);
    }

    public String getDescripcion_albañil() {
        return descripcion_albañil;
    }

    public void setDescripcion_albañil(String descripcion_albañil) {
        this.descripcion_albañil=descripcion_albañil;
    }
    
    @Override
    public String seguridad(){
       return "Al ser albañil, debe usar rodilleras para su trabajo en superficies duras";
    }
}