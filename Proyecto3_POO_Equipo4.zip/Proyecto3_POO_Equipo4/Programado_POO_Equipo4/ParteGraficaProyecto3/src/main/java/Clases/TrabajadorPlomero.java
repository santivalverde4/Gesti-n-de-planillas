package Clases;
public class TrabajadorPlomero extends Trabajador {
    
    private String descripcion_plom = "el plomero de la empresa tiene una queja acerca de esta, la cual es: ";

    public TrabajadorPlomero(String nombre,String cedula,TGenero genero, String reporte, String direccion, String telefono, String descripcion_plom) {
        super(nombre, cedula, genero,reporte, direccion, telefono);
        this.descripcion_plom = descripcion_plom;
    }

    public String getdescripcion_plom() {
        return descripcion_plom;
    }

    public void setdescripcion_plom(String descripcion_plom) {
        this.descripcion_plom=descripcion_plom;
    }
    
    @Override
    public String seguridad(){
        return "Al ser plomero, debe usar guantes resistentes a productos químicos para manipular materiales peligrosos";
    }
    
    
}
