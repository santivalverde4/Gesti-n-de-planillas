package Clases;
import java.util.ArrayList;
import GUI.FRAME1;
public class main{
    public static void main(String[] args){

        /* 
        ManejadorArchivoTexto manejadorArchivoTexto = new ManejadorArchivoTexto();
        manejadorArchivoTexto.leerYImprimirCodigoTrabajo();*/


        TrabajadorAlbañil trabajadorAlbañil = new TrabajadorAlbañil("Juan", "1", TGenero.MASCULINO, "reporte", "direccion", "telefono");
        TrabajadorElectricista trabajadorElectricista = new TrabajadorElectricista("Juan", "2", TGenero.MASCULINO, "reporte", "direccion", "telefono");
        
        ArrayList<Trabajador> trabajadores = new ArrayList<Trabajador>();
        trabajadores.add(trabajadorAlbañil);
        trabajadores.add(trabajadorElectricista);
        Administrador admin=new Administrador("10","x","a","d","c",trabajadores);
        //System.err.println(admin.validarNombreTrabajador(""));
        //System.err.println(admin.validarCedulaTrabajador("1")); 
        //trabajadorAlbañil.redactarReporte("Hola");
        //trabajadorElectricista.redactarReporte("Adios");
        //System.out.println(trabajadorAlbañil.getReporte());   
        //admin.consultarReportes();
        //admin.generarDiagnostico();
        admin.eliminarTrabajador("Juan", "1");
        FRAME1 ventana=new FRAME1();
        ventana.setVisible(true);

        
    }
}
