package Clases;
public abstract class Trabajador {
    protected String nombre;
    protected String cedula;
    protected TGenero genero;
    protected String reporte;
    protected String direccion;
    protected String telefono;
    public abstract String seguridad();


/**
 * Para ver_reporte, el CEO va a ver todo normal
 * 
 * Para el trabajador se va a hacer anonimo, tipo cada que se emvia un reporte 
 * se manda la cedula del que puso el reporte en un txt, para que luego el metodo
 * de ver_reporte del trabajador nada mas sea extraer esas cedulas y mostrarlas
 */


    public Trabajador(String nombre, String cedula, TGenero genero, String reporte, String direccion, String telefono) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.genero = genero;
        this.reporte = reporte;
        this.direccion = direccion;
        this.telefono = telefono;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public TGenero getGenero() {
        return genero;
    }

    public void setGenero(TGenero genero) {
        this.genero = genero;
    }

    public String getReporte() {
        return reporte;
    }

    public void setReporte(String reporte) {
        this.reporte = reporte;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    @Override
    public String toString() {
        return "Trabajador [nombre=" + nombre + ", cedula=" + cedula + ", genero=" + genero + ", reporte=" + reporte
                + ", direccion=" + direccion + ", telefono=" + telefono + "]";
    }

    //***************************************************************************************

    public void redactarReporte(String reporte){
        this.reporte = reporte;
    }
    
 

    
    
    

}
