package Clases;
public class TrabajadorSupervisor extends Trabajador {
    private String descripcion_supervisor = "El supervisor de la empresa ha notado cierto detalle acerca de la obra: ";

    public TrabajadorSupervisor(String nombre,String cedula,TGenero genero, String reporte, String direccion, String telefono,String descripcion_supervisor) {
        super(nombre,cedula,genero,reporte, direccion,telefono);
        this.descripcion_supervisor=descripcion_supervisor;
    }

    public String getdescripcion_supervisor() {
        return descripcion_supervisor;
    }

    public void setdescripcion_supervisor(String descripcion_supervisor) {
        this.descripcion_supervisor=descripcion_supervisor;
    }
    
    @Override
    public String seguridad(){
        return "Al ser supervisor, debe usar una tablet resistente a impactos para actividades en el sitio de construcción";
    }
        
}
