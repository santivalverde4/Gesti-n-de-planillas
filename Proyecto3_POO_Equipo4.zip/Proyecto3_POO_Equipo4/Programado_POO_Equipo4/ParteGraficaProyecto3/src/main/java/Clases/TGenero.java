package Clases;
public enum TGenero {
    MASCULINO, FEMENINO,OTRO
}