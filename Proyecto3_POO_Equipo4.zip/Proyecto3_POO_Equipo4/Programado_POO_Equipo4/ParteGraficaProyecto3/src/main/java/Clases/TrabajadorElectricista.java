package Clases;
public class TrabajadorElectricista extends Trabajador {
    private String descripcion_elec = "El trabajador tiene un rol de electricista y sus quejas con respecto a la empresa son: ";

    public TrabajadorElectricista(String nombre,String cedula,TGenero genero, String reporte, String direccion, String telefono) {
        super(nombre, cedula, genero,reporte, direccion, telefono);
    }

    public String getdescripcion_elec() {
        return descripcion_elec;
    }

    public void setdescripcion_elec(String descripcion_elec) {
        this.descripcion_elec=descripcion_elec;
    }
    
    @Override
    public String seguridad(){
        return "Al ser electricista, debe usar un detector de voltaje sin contacto para comprobar la presencia de corriente de manera segura";
    }

}
