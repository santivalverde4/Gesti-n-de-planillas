package Clases;
public class TrabajadorArquitecto extends Trabajador {
    private String descripcion_arquitecto= "El trabajador tiene un rol de arquitecto y sus quejas con respecto a la empresa son: ";

    public TrabajadorArquitecto(String nombre,String cedula,TGenero genero, String reporte, String direccion, String telefono) {
        super(nombre, cedula, genero,reporte, direccion, telefono);
    }

    public String getDescripcion_arquitecto() {
        return descripcion_arquitecto;
    }

    public void setDescripcion_arquitecto(String descripcion_arquitecto) {
        this.descripcion_arquitecto=descripcion_arquitecto;
    }
    
    @Override
    public String seguridad(){ 
        return "Al ser arquitecto, debe usar un portaplanos resistente para proteger y transportar planos importantes";
    }

}
