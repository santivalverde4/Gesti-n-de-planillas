package Clases;
public enum Tjornada{

TIEMPO_COMPLETO, MEDIO_TIEMPO,
PASANTIA, PRACTICA, NOCTURNA

}