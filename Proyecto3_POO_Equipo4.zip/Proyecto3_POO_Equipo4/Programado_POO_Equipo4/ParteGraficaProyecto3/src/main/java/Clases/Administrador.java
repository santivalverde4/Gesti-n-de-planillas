package Clases;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Administrador {
    private String nombre_empresa;
    private String año;
    private String socios; 
    private String direccion;
    private String horario_atencion;
    public ArrayList<Trabajador> trabajadores;
    private boolean inicio = false;

    public Administrador() {
    }

    public Administrador(String año, String direccion, String horario_atencion, String nombre_empresa, String socios, ArrayList<Trabajador> trabajadores) {
        this.año = año;
        this.direccion = direccion;
        this.horario_atencion = horario_atencion;
        this.nombre_empresa = nombre_empresa;
        this.socios = socios;
        this.trabajadores = trabajadores;
        
    }


    public String getNombre_empresa() {
        return nombre_empresa;
    }

    public void setNombre_empresa(String nombre_empresa) {
        this.nombre_empresa = nombre_empresa;
    }

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }
    
    public boolean getinicio() {
        return inicio;
    }

    public void setinicio(boolean inicio) {
        this.inicio = inicio;
    }
    
    
    
    
    
    
    

    public String getSocios() {
        return socios;
    }

    public void setSocios(String socios) {
        this.socios = socios;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getHorario_atencion() {
        return horario_atencion;
    }

    public void setHorario_atencion(String horario_atencion) {
        this.horario_atencion = horario_atencion;
    }

    public ArrayList<Trabajador> getTrabajadores() {
        return trabajadores;
    }

    public void setTrabajadores(ArrayList<Trabajador> trabajadores) {
        this.trabajadores = trabajadores;
    }

    

    @Override
    public String toString() {
        return "Administrador [nombre_empresa=" + nombre_empresa + ", año=" + año + ", socios=" + socios
                + ", direccion=" + direccion + ", horario_atencion=" + horario_atencion + ", trabajadores="
                + trabajadores + "]";
    }

    //*****************************METODOS PROPIOS******************************************************

    //Ingresar trabajador
    public boolean  validarNombreTrabajador (String nombre){
        if (nombre.length()==0){
            
            return false;
        }
        return true;
    }

    public boolean validarCedulaTrabajador (String cedula){
        if (cedula.length()==0){
            System.out.println("La cedula no puede estar vacia");
            return false;
        }
        else{
            for(int i=0;i<trabajadores.size();i++){
                Trabajador trabajador = trabajadores.get(i);
                if (trabajador.getCedula().equals(cedula)){
                    return true;
                }
            }
            System.out.println("La cedula no se encuentra en la lista de trabajadores");
            return false;
        }
    }

    //Ingresar admin
    public boolean validarNombreEmpresa(String nombre){
        if (nombre.length()==0){
            System.out.println("El nombre no puede estar vacio");
            return false;
        }
        return true;
    }

    public boolean validarAño(int año){
        if (año<1500){
            System.out.println("El año debe ser mayor a 1500");
            return false;
        }
        return true;
    }

    public boolean validarSocios(String socios){
        if (socios.length()==0){
            System.out.println("La lista de socios no puede estar vacia");
            return false;
        }
        return true;
    }

    public boolean validarUbicacion(String direccion){
        if (direccion.length()==0){
            System.out.println("La ubicacion no puede estar vacia");
            return false;
        }
        return true;
    }

    public boolean validarHorario(String horario){
        if (horario.length()==0){
            System.out.println("El horario no puede estar vacio");
            return false;
        }
        return true;
    }

    //Funciones Administrador

    int contador=0;

    public void consultarReportes() {
        for (int i = 0; i < trabajadores.size(); i++) {
            Trabajador trabajador = trabajadores.get(i);
            if (trabajador instanceof TrabajadorAlbañil) {
                System.out.println(((TrabajadorAlbañil) trabajador).getDescripcion_albañil());
                System.out.println(trabajador.getReporte());
                contador++;
            }
            else if(trabajador instanceof TrabajadorElectricista){
                System.out.println(((TrabajadorElectricista) trabajador).getdescripcion_elec());
                System.out.println(trabajador.getReporte());
                contador++;
            }
            else if(trabajador instanceof TrabajadorArquitecto){
                System.out.println(((TrabajadorArquitecto) trabajador).getDescripcion_arquitecto());
                System.out.println(trabajador.getReporte());
                contador++;
            }
            else if(trabajador instanceof TrabajadorSupervisor){
                System.out.println(((TrabajadorSupervisor) trabajador).getdescripcion_supervisor());
                System.out.println(trabajador.getReporte());
                contador++;
            }
            else{
                System.out.println(((TrabajadorPlomero) trabajador).getdescripcion_plom());
                System.out.println(trabajador.getReporte());
                contador++;
            }
        }
    }

    public void generarDiagnostico(){
        System.out.println("El numero de reportes generados por los trabajadores es: "+contador);
        if(contador<1){
            System.out.println("La seguridad de la empresa es excelente");
        }
        else if(contador<4){
            System.out.println("La seguridad de la empresa es leve");
        }
        else if(contador>=4){
            System.out.println("La seguridad de la empresa es mala");
        }
    }

    public void eliminarTrabajador(String nombre, String cedula){
        boolean eliminado = false;

        for (int i = 0; i < trabajadores.size(); i++) {
            Trabajador trabajador = trabajadores.get(i);
            
            if (trabajador.getNombre().equals(nombre) && trabajador.getCedula().equals(cedula)) {
                trabajadores.remove(i); // Eliminar el trabajador
                eliminado = true; // Marcar que se ha eliminado
                JOptionPane.showMessageDialog(null, "El trabajador " + nombre + " ha sido eliminado", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                break; // Salir del bucle una vez que se elimina
            }
        }
        

      
       
    }
    
    }
    


    /*
     * import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public void consultarReportes(String nombreArchivo) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
        for (int i = 0; i < trabajadores.size(); i++) {
            Trabajador trabajador = trabajadores.get(i);
            if (trabajador instanceof TrabajadorAlbañil) {
                writer.write(((TrabajadorAlbañil) trabajador).getDescripcion_albañil());
                writer.newLine();
                writer.write(trabajador.getReporte());
                writer.newLine();
            } else if (trabajador instanceof TrabajadorElectricista) {
                writer.write(((TrabajadorElectricista) trabajador).getdescripcion_elec());
                writer.newLine();
                writer.write(trabajador.getReporte());
                writer.newLine();
            } else if (trabajador instanceof TrabajadorArquitecto) {
                writer.write(((TrabajadorArquitecto) trabajador).getDescripcion_arquitecto());
                writer.newLine();
                writer.write(trabajador.getReporte());
                writer.newLine();
            } else if (trabajador instanceof TrabajadorSupervisor) {
                writer.write(((TrabajadorSupervisor) trabajador).getdescripcion_supervisor());
                writer.newLine();
                writer.write(trabajador.getReporte());
                writer.newLine();
            } else if (trabajador instanceof TrabajadorPlomero) {
                writer.write(((TrabajadorPlomero) trabajador).getdescripcion_plom());
                writer.newLine();
                writer.write(trabajador.getReporte());
                writer.newLine();
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
     */
    








